package com.RegistrationAndLoginUsingAjaxServlet.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.RegistrationAndLoginUsingAjaxServlet.beans.LoginOutputBean;
import com.RegistrationAndLoginUsingAjaxServlet.beans.RegistrationOutputBean;
import com.RegistrationAndLoginUsingAjaxServlet.helper.Loginhelper;
import com.RegistrationAndLoginUsingAjaxServlet.helper.Registerhelper;

/**
 * Servlet implementation class ServletController
 */
public class ServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletController() 
    {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String action=request.getParameter("action");
		if(action!=null && !"".equals(action))
		{
				if("register".equals(action))
				{
					Map map=new TreeMap();
					map.clear();
					map.put("firstname", request.getParameter("FirstName"));
					map.put("lastname", request.getParameter("LastName"));
					map.put("mobile", request.getParameter("Mobile"));
					map.put("pincode", request.getParameter("Pincode"));
					map.put("email", request.getParameter("Email"));
					map.put("dateofbirth", request.getParameter("mdate1"));
					map.put("password", request.getParameter("mpassword"));
					map.put("gender", request.getParameter("gender"));
					map.put("hobbie", request.getParameter("Hobbie"));
					map.put("address", request.getParameter("Address"));
					map.put("city", request.getParameter("city"));
					RegistrationOutputBean registrationOutputBean=new Registerhelper().RegisterSubmit(map);
					if(registrationOutputBean.isStatus())
					{
						request.setAttribute("message",registrationOutputBean.getMessage());
						request.setAttribute("data", registrationOutputBean.getData());
						request.getRequestDispatcher("jsp/success.jsp").forward(request, response);
					}
					else
					{
						request.setAttribute("message",registrationOutputBean.getMessage());
						request.getRequestDispatcher("jsp/failed.jsp").forward(request,response);
					}
				}
		}
		else
		{
			request.getRequestDispatcher("jsp/error.jsp").forward(request,response);
		}
	}

}
