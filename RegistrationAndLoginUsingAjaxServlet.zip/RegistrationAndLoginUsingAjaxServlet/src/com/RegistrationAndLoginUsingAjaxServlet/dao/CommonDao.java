package com.RegistrationAndLoginUsingAjaxServlet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.RegistrationAndLoginUsingAjaxServlet.beans.LoginInputBean;
import com.RegistrationAndLoginUsingAjaxServlet.beans.RegistrationInputBean;
import com.RegistrationAndLoginUsingAjaxServlet.utils.DBconnection;


public class CommonDao 
{
	
	public List checkData(LoginInputBean inputBean)
	{
		List list=new ArrayList();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{
			Connection con=DBconnection.getconnection();
			ps=con.prepareStatement("select firstname,admin from EmployeeData where email=? and password=?");
			ps.setString(1, inputBean.getEmail());
			ps.setString(2, inputBean.getPassword());
			
			rs=ps.executeQuery();
			if(rs!=null)
			{
				while(rs.next())
				{
					
						list.add(rs.getString(1));
						list.add(rs.getString(2));
				}
			}
			else
			{
				list.clear();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
			DBconnection.closeconnection();
			ps.close();
			rs.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return list;
	}

	public String checkEmail(String email) 
	{
		String checkemail=null;
		try
		{
			
			Connection con=DBconnection.getconnection();
			PreparedStatement ps=con.prepareStatement("select email from EmployeeData where email=?");
			ps.setString(1,email);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				checkemail=rs.getString(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DBconnection.closeconnection();
		}
		return checkemail;
	}
	
	public String checkPassword(String password,String email) 
	{
		String checkPassword=null;
		try
		{
			
			Connection con=DBconnection.getconnection();
			PreparedStatement ps=con.prepareStatement("select password from EmployeeData where password=? and email=?");
			ps.setString(1,password);
			ps.setString(2,email);
			
			ResultSet rs=ps.executeQuery();
			
			if(rs!=null)
			{
				while(rs.next())
				{
					
						checkPassword=rs.getString(1);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DBconnection.closeconnection();
		}
		return checkPassword;
	}

	public boolean registerData(RegistrationInputBean registrationInputBean) 
	{
		try 
		{
			Connection con = DBconnection.getconnection();
			PreparedStatement ps = con.prepareStatement("insert into EmployeeData(firstname,lastname,gender,date_of_birth,mobile,email,password,hobbies,city,address,pincode,createdBy,createdDate,modifiedBy,modifiedDate) values(?,?,?,?,?,?,?,?,?,?,?,1,now(),1,now())");
			ps.setString(1, registrationInputBean.getFirstname());
			ps.setString(2, registrationInputBean.getLastname());
			ps.setString(3, registrationInputBean.getGender());
			ps.setString(4, registrationInputBean.getDateofbirth());
			ps.setString(5, registrationInputBean.getMobile());
			ps.setString(6, registrationInputBean.getEmail());
			ps.setString(7, registrationInputBean.getPassword());
			ps.setString(8, registrationInputBean.getHobbies());
			ps.setString(9, registrationInputBean.getAddress());
			ps.setString(10, registrationInputBean.getCity());
			ps.setString(11, registrationInputBean.getPincode());
			
			int result=ps.executeUpdate();
			if(result!=0)
			{
				return true;
			}
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			DBconnection.closeconnection();
		}
		return false;

	}

	public String checkmobile(String mobile) 
	{
		String checked=null;
		try
		{
			
			Connection con=DBconnection.getconnection();
			PreparedStatement ps=con.prepareStatement("select mobile from EmployeeData where mobile=?");
			ps.setString(1,mobile);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				checked=rs.getString(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DBconnection.closeconnection();
		}
		return checked;

	}
	
	public Map showtable()
	{
		List list=new ArrayList();
		HashMap hashmap=new HashMap();
		try
		{
			
			Connection con=DBconnection.getconnection();
			PreparedStatement ps=con.prepareStatement("select firstname,lastname,gender,date_of_birth,mobile,email,password,hobbies,city,address,pincode from EmployeeData");
			ResultSet rs=ps.executeQuery();
			if(rs!=null)
			{
				while(rs.next())
				{
					list.add(rs.getString(1));
					list.add(rs.getString(2));
					list.add(rs.getString(3));
					list.add(rs.getString(4));
					list.add(rs.getString(5));
					list.add(rs.getString(6));
					list.add(rs.getString(7));
					list.add(rs.getString(8));
					list.add(rs.getString(9));
					list.add(rs.getString(10));
					list.add(rs.getString(11));
				}
				hashmap.put("show", list);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			DBconnection.closeconnection();
		}
		return hashmap;
	}
	
}
