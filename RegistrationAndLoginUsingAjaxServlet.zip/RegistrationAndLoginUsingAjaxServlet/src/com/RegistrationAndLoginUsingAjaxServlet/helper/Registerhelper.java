package com.RegistrationAndLoginUsingAjaxServlet.helper;

import java.util.Map;

import com.RegistrationAndLoginUsingAjaxServlet.beans.LoginOutputBean;
import com.RegistrationAndLoginUsingAjaxServlet.beans.RegistrationInputBean;
import com.RegistrationAndLoginUsingAjaxServlet.beans.RegistrationOutputBean;
import com.RegistrationAndLoginUsingAjaxServlet.dao.CommonDao;
import com.RegistrationAndLoginUsingAjaxServlet.utils.DBconnection;

public class Registerhelper 
{
	
	public RegistrationOutputBean RegisterSubmit(Map map) 
	{
		RegistrationOutputBean registrationOutputBean=new RegistrationOutputBean();
		RegistrationInputBean registrationInputBean=new RegistrationInputBean();
		registrationInputBean.setFirstname(map.get("firstname")+"");
		registrationInputBean.setLastname(map.get("lastname")+"");
		registrationInputBean.setMobile(map.get("mobile")+"");
		registrationInputBean.setPincode(map.get("pincode")+"");
		registrationInputBean.setEmail(map.get("email")+"");
		registrationInputBean.setDateofbirth(map.get("dateofbirth")+"");
		registrationInputBean.setPassword(map.get("password")+"");
		registrationInputBean.setGender(map.get("gender")+"");
		registrationInputBean.setHobbies(map.get("hobbie")+"");
		registrationInputBean.setAddress(map.get("address")+"");
		registrationInputBean.setCity(map.get("city")+"");
		
		boolean data=new CommonDao().registerData(registrationInputBean);
		
		if(data)
		{
			registrationOutputBean.setStatus(true);
			registrationOutputBean.setData(map.get("firstname")+"");
			registrationOutputBean.setMessage("Data inserted successfully");
			
		}
		else
		{
			registrationOutputBean.setStatus(false);
			registrationOutputBean.setMessage("Data not inserted");
		}
		return registrationOutputBean;
	}
	
	public String checkEmail(String email)
	{
		
		RegistrationOutputBean registrationOutputBean=new RegistrationOutputBean();
		if(email!=null && !"".equals(email))
		{
			String checkedEmail=new CommonDao().checkEmail(email);
			if(checkedEmail!=null)
			{
				if(checkedEmail.equals(email))
				{
					registrationOutputBean.setStatus(true);
					registrationOutputBean.setData(checkedEmail);
					registrationOutputBean.setMessage("is exist");
					
				}
				else
				{
					registrationOutputBean.setStatus(false);
				}
			}
			else
			{
				registrationOutputBean.setStatus(false);
			}
		}
		else
		{
			registrationOutputBean.setStatus(false);
		}
		return DBconnection.toJson(registrationOutputBean);
	}
	
	public String checkmobile(String mobile)
	{
		
		RegistrationOutputBean registrationOutputBean=new RegistrationOutputBean();
		if(mobile!=null && !"".equals(mobile))
		{
			String checked=new CommonDao().checkmobile(mobile);
			if(checked!=null)
			{
				if(checked.equals(mobile))
				{
					registrationOutputBean.setStatus(true);
					registrationOutputBean.setData(checked);
					registrationOutputBean.setMessage("is exist");
					
				}
				else
				{
					registrationOutputBean.setStatus(false);
				}
			}
			else
			{
				registrationOutputBean.setStatus(false);
			}
		}
		else
		{
			registrationOutputBean.setStatus(false);
		}
		return DBconnection.toJson(registrationOutputBean);
	}
	
}
