package com.RegistrationAndLoginUsingAjaxServlet.helper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.RegistrationAndLoginUsingAjaxServlet.beans.LoginInputBean;
import com.RegistrationAndLoginUsingAjaxServlet.beans.LoginOutputBean;
import com.RegistrationAndLoginUsingAjaxServlet.dao.CommonDao;
import com.RegistrationAndLoginUsingAjaxServlet.utils.DBconnection;

public class Loginhelper 
{
	CommonDao commonDao=new CommonDao();
	public String loginSubmit(String Email,String password)
	{
		
		LoginOutputBean loginOutputBean=new LoginOutputBean();
		if(Email!=null && !"".equals(Email) && password!=null && !"".equals(password))
		{
			LoginInputBean inputBean=new LoginInputBean();
			inputBean.setEmail(Email);
			inputBean.setPassword(password);
			
			List list=commonDao.checkData(inputBean);
		
			if(list!=null && !list.isEmpty())// && temppassword!=null && !"".equals(tempEmail) && !"".equals(temppassword))
			{
				loginOutputBean.setStatus(true);
				loginOutputBean.setMessage("login successfully");
				loginOutputBean.setData(list.get(0)+"");
				loginOutputBean.setEntry(list.get(1)+"");
			}
			else
			{
				
				loginOutputBean.setStatus(false);
				loginOutputBean.setMessage("Email and password are not present");
			}
		}
		else
		{
			
			loginOutputBean.setStatus(false);
			loginOutputBean.setMessage("Email and password not valid");
		}
		return DBconnection.toJson(loginOutputBean);
		
	}
	
	public String checkEmail(String email)
	{
		
		LoginOutputBean loginOutputBean=new LoginOutputBean();
		if(email!=null && !"".equals(email))
		{
			String checkedEmail=commonDao.checkEmail(email);
			if(checkedEmail!=null)
			{
				if(checkedEmail.equals(email))
				{
					loginOutputBean.setStatus(true);
					loginOutputBean.setData(checkedEmail);
					loginOutputBean.setMessage("is exist");
					
				}
				else
				{
					loginOutputBean.setStatus(false);
				}
			}
			else
			{
				loginOutputBean.setMessage("Email is not exist");
				loginOutputBean.setStatus(false);
			}
		}
		else
		{
			loginOutputBean.setStatus(false);
		}
		return DBconnection.toJson(loginOutputBean);
	}
	
	public String checkPassword(String password,String email)
	{
		
		LoginOutputBean loginOutputBean=new LoginOutputBean();
		if(password!=null && !"".equals(password) && email!=null && !"".equals(email))
		{
			String checkedpassword=commonDao.checkPassword(password,email);
			if(checkedpassword!=null)
			{
				if(checkedpassword.equals(password))
				{
					loginOutputBean.setStatus(true);
					loginOutputBean.setData(checkedpassword);
					loginOutputBean.setMessage("is exist");
				}
				else
				{
					loginOutputBean.setStatus(false);
									}
			}
			else
			{
				loginOutputBean.setMessage("mismatch");
				loginOutputBean.setStatus(false);
			}
		}
		else
		{
			loginOutputBean.setStatus(false);
		}
		return DBconnection.toJson(loginOutputBean);
	}
	
	public String showtable()
	{
		HashMap hashMap=new HashMap();
		hashMap=(HashMap)new CommonDao().showtable();
		LoginOutputBean loginOutputBean=new LoginOutputBean();
		loginOutputBean.setList((ArrayList)hashMap.get("show"));
		loginOutputBean.setStatus(true);
		return DBconnection.toJson(loginOutputBean);
	}
	
}
