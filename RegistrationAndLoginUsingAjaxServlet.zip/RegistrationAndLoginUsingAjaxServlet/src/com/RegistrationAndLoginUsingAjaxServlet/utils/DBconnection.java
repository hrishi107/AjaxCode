package com.RegistrationAndLoginUsingAjaxServlet.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;



public class DBconnection 
{
	static Connection conn;
	public static Connection getconnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://192.168.57.5:3306/vishwajeet_deshmukh","vishwa_deshmukh","vishwa_deshmukh");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return conn;
		
	}
	
	public static void closeconnection()
	{
		try 
		{
			conn.close();
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public static String toJson(Object obj)
	{
		Gson gson=new GsonBuilder().create();
		return gson.toJson(obj);
	}
}
