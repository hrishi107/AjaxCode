package com.RegistrationAndLoginUsingAjaxServlet.beans;

import java.util.ArrayList;


public class LoginOutputBean
{
	private boolean status;
	private String message;
	private String data;
	private String entry;
	private ArrayList list;
	
	public ArrayList getList() {
		return list;
	}
	public void setList(ArrayList list) {
		this.list = list;
	}
	public String getEntry() {
		return entry;
	}
	public void setEntry(String entry) {
		this.entry = entry;
	}
	public boolean isStatus()
	{
		return status;
	}
	public void setStatus(boolean status)
	{
		this.status = status;
	}
	public String getMessage()
	{
		return message;
	}
	public void setMessage(String message)
	{
		this.message = message;
	}
	public String getData() 
	{
		return data;
	}
	public void setData(String data)
	{
		this.data = data;
	}
	
}
