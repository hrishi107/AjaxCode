var validate=new formvalidation();

function formvalidation()
{
	this.loginpopup=loginpopup;
	function loginpopup()
	{
		$("#loginpopup").removeClass("displaynone");
		$("#loginpopup").addClass("popup1");
		$("#wrapperpopup").addClass("wrapperpopup");
		$(".divclick").removeClass("displaynone");
		
	}

	this.registerpopup=registerpopup;
	function registerpopup()
	{
		$("#registerpopup").removeClass("displaynone");
		$("#registerpopup").addClass("popup2");
		$("#wrapperpopup").addClass("wrapperpopup");
		$(".divclick").removeClass("displaynone");

	}
	
	this.removepopup=removepopup;
	function removepopup()
	{
		$("#registerpopup").addClass("displaynone");
		$("#loginpopup").addClass("displaynone");
		$("#loginpopup2").addClass("displaynone");
		$("#registerpopup").removeClass("popup2")
		$("#loginpopup").removeClass("popup1")
		$("#wrapperpopup").removeClass("wrapperpopup")
		$(".divclick").addClass("displaynone");
		$("#form").removeClass("displaynone");
		$("#show").addClass("displaynone");
		resetdata();

	}

	this.showdata=showdata;
	function showdata()
	{
		$("#form").addClass("displaynone");
		$("#show").removeClass("displaynone");
	}

	this.showdata2=showdata2;
	function showdata2()
	{
		$("#loginpopup").addClass("displaynone");
		$("#loginpopup").removeClass("popup1")
		$("#loginpopup2").removeClass("displaynone");
		$("#loginpopup2").addClass("popup1")
		
	}


	var char1=/^[a-zA-Z]{2,15}$/;
	var gendervalue=0;
	var hobbiesdata="";
	this.checkinput=checkinput;
	function checkinput(name)
	{
		if(name==undefined || name==null || name=="" )
		{
			return false;
		}

		else
		{
			return true;
		}

	}

	var firstnamevalue;
	this.validatefirstname=validatefirstname;
	function validatefirstname()
	{
		var firstname=$("#FirstName").val();
		if(!checkinput(firstname))
		{
			$("#spanFirstName").text("firstname not empty");
			return false;
		}
		else if(!char1.test(firstname))
		{
			
			$("#spanFirstName").text("firstname not valid");
			return false;
		}
		else
		{
			firstnamevalue=firstname;
			$("#spanFirstName").text("");
			return true;
		}

	}

	var lastnamevalue;
	this.validatelastname=validatelastname;
	function validatelastname()
	{
		var lastname=$("#LastName").val();
		if(!checkinput(lastname))
		{
			$("#spanLastName").text("lastName not empty");
			return false;
		}
		else if(!char1.test(lastname))
		{
			
			$("#spanLastName").text("lastName not valid");
			return false;
		}
		else
		{
			lastnamevalue=lastname;
			$("#spanLastName").text("");
			return true;				
		}

	}

	var mobilenovalue;
	this.validatemobileNo=validatemobileNo;
	var num1=/^[7-9][0-9]{9}$/;
	function validatemobileNo()
	{
		var mobileNo=$("#Mobile").val();
		if(!checkinput(mobileNo))
		{
			$("#spanmobile").text("mobileno not empty");
			return false;
		}
		else if(!num1.test(mobileNo))
		{
			$("#spanmobile").text("mobileno not valid");
			return false;
		}
		else
		{
			mobilenovalue=mobileNo;
			$("#spanmobile").text(" ");
			return true;
		}

	}


	var pinvalue;
	this.validatepincode=validatepincode;
	var pincoderegex=/^[1-9][0-9]{5}$/;
	function validatepincode()
	{
		var pincode=$("#Pincode").val();
		if(!checkinput(pincode))
		{
			$("#spanpincode").text("pincode not empty");
			return false;
		}
		else if(!pincoderegex.test(pincode))
		{
			
			$("#spanpincode").text("pincode not valid");
			return false;
		}
		else
		{
			pinvalue=pincode;
			$("#spanpincode").text("");
			return true;
		}

	}


	this.validategender=validategender;
	function validategender()
	{
		var gender=$(".radiobutton");
		for(var i=0;i<gender.length;i++)
		{
			if(gender[i].checked)
			{
				gendervalue=gender[i].value;
				
			}
		}

		if(gendervalue==0)
		{
			$("#spanGender").text("please select gender");
			return false;
		}

		else
		{
			$("#spanGender").text(" ");
			return true;
		}

	}

	var emailvalue;
	this.validateemail=validateemail;
	function validateemail()
	{
		var email=$("#Email").val();
		var emailregex=/^[a-zA-Z0-9][a-zA-Z0-9]*[.-_]{0,2}[a-zA-Z0-9]*[@][a-zA-Z]*([.][a-zA-Z]{2,3}|[.][a-zA-Z]*[.][a-zA-Z]{2,3})$/;
		if(!checkinput(email))
		{
			$("#spanEmail").text("Email not empty");
			return false;
		}
		if(!emailregex.test(email))
		{
			emailvalue=email;
			$("#spanEmail").text("Email not valid");
			return false;
		}
		else
		{
			$("#spanEmail").text("");
			return true;
		}

	}

	var password;
	this.validatepassword=validatepassword;
	function validatepassword()
	{
		password=$("#mpassword").val();
		var pass=/^([a-zA-z0-9]{4})([!@#$%^&*])([a-zA-Z0-9]{3})$/;
		if(!checkinput(password))
		{
			$("#spanPassword").text("Password not empty");
			return false;
		}

		else if(!pass.test(password))
		{
			$("#spanPassword").text("Password not valid");
			return false;
		}

		else
		{
			$("#spanPassword").text("");
			return true;
		}

	}
	
	this.confirmpassword=confirmpassword;
	function confirmpassword()
	{

		var confirmpassword=$("#cpassword").val();
		if(!checkinput(confirmpassword))
		{
			$("#spancofirmPassword").text("Password not empty");
			return false;
		}
		
		else if(confirmpassword!=password)
		{
			$("#spancofirmPassword").text("Password not match");
			return false;
		}

		else
		{
			$("#spancofirmPassword").text("");
			return true;
		}

	}

	var datevalue;
	this.validateDate=validateDate;
	function validateDate()
	{
		var date12=$("#mdate1").val();
		var d=/([1][7-9][0-9][0-9]|[2][0][0][0-2])[/]([0][1-9]|[1][0-2])[/]([0][1-9]|[1-2][0-9]|[3][0-1])/;
		if(!checkinput(date12))
		{
			$("#spandate").text("date not empty");
			return false;
		}
		else if(!d.test(date12))
		{
			
			$("#spandate").text("date not valid");
			return false;
		}
		else
		{
			datevalue=date12;
			$("#spandate").text("");
			return true;
		}

	}
	

	var hobbiesvalue;
	this.validatehobbies=validatehobbies;
	function validatehobbies()
	{
		
		var Hobbies=$(".hobbiesclass");
		var count=0;
		for(var i=0;i<Hobbies.length;i++)
		{
			if(Hobbies[i].checked)
			{
				hobbiesdata=hobbiesdata+Hobbies[i].value+"";
				count++;
			}
		
		}
		hobbiesvalue=hobbiesdata;
		hobbiesdata="";
		
		if(count!=0)
		{
			$("#spanHobbies").text("");
			return true;
		}

		else
		{
			$("#spanHobbies").text("please select Hobbies");
			return false;
		}

	}

	var addressvalue;
	this.validateAddress=validateAddress;
	function validateAddress()
	{
		
		var Address=($("#Address").val()).trim();
		if(checkinput(Address))
		{
			addressvalue=Address;
			$("#spanAddress").text(" ");
			return true;
		}
		else
		{
			$("#spanAddress").text("Address is not valid");
			return false;
		}

	}
	
	var cityvalue;
	this.validatecity=validatecity;
	function validatecity()
	{
		var city = $('#dropdown').find('option:selected').text();
		if(city!="select")
		{	
			cityvalue=city;
			$("#spandropdown").text(" ");
			return true;
		}
		else if(!checkinput(city))
		{
			
			$("#spandropdown").text("Please select a city");
			return false;
		}
		else
		{
			$("#spandropdown").text("Please select a city");
			return false;
		}
		
	
	}

	this.submitdata=submitdata;
	function submitdata()
	{
		if(validatefirstname() && validatelastname() && validatemobileNo() && validatepincode()  && validateemail()  && validateDate() && validatepassword() && confirmpassword()  &&  validategender() && validatehobbies() && validateAddress() && validatecity())
		{
			
			$("#t1").text("FirstName : "+firstnamevalue);
			$("#t2").text("LastName : "+lastnamevalue);
			$("#t3").text("Gender : "+gendervalue);
			$("#t4").text("Mobile No. : "+mobilenovalue);
			$("#t5").text("Email Id : "+emailvalue);
			$("#t6").text("Password : "+password);
			$("#t7").text("Date of Birth : "+datevalue);
			$("#t8").text("Hobbies : "+hobbiesvalue);
			$("#t9").text("Address : "+addressvalue);
			$("#t10").text("pincode : "+pinvalue);
			$("#t11").text("city : "+cityvalue);
			showdata();
			return true;
		}
		else
		{
			return false;
		}
	}
	
	var loginemail="vishwajeet@gmail.com";
	var loginMobile="9730835749";
	var loginEmailvalue;
	this.validateloginEmail=validateloginEmail
	function validateloginEmail()
	{
		var emailregex=/^[a-zA-Z0-9][a-zA-Z0-9]*[.-_]{0,2}[a-zA-Z0-9]*[@][a-zA-Z]*([.][a-zA-Z]{2,3}|[.][a-zA-Z]*[.][a-zA-Z]{2,3})$/;
		var loginEmail=$("#loginEmail").val();
		if(!checkinput(loginEmail))
		{
			$("#Emailerror").text("please enter email/phoneno.");
			return false;
		}
		else if(!emailregex.test(loginEmail))
		{
			loginEmailvalue=loginEmail;
			$("#spanEmail").text("Email not valid");
			return false;
		}
		else
		{
			$("#Emailerror").text("");
			return true;
		}

	}

	
	var loginpvalue;
	this.validateloginpassword=validateloginpassword
	function validateloginpassword()
	{
		var pass=/^([a-zA-z0-9]{4})([!@#$%^&*])([a-zA-Z0-9]{3})$/;
		var loginp=$("#loginpassword").val();
		if(!checkinput(loginp))
		{
			$("#passworderror").text("please enter password");
			return false;
		}
		else if(!pass.test(loginp))
		{
			loginpvalue=loginp;
			$("#passworderror").text("password not valid");
			return false;
			
		}
		else
		{
			$("#passworderror").text("");
			return true;
		}

	}

	this.logindata=logindata;
	function logindata()
	{
		if(validateloginEmail() && validateloginpassword())
		{
			$("#l1").text("EmailID/PhoneNo : "+loginEmailvalue);
			$("#l2").text("password : "+loginpvalue);
			showdata2();
			return true;
		}
		else
		{
			return false;
		}
	}

	this.resetdata=resetdata;
	function resetdata()
	{
		$(".spanvaliadate").text("");
		$("#FirstName").val("");
		$("#LastName").val("");
		$("#Mobile").val("");
		$("#Pincode").val("");
		$("#g1").val("");
		$("#Email").val("");
		$("#mpassword").val("");
		$("#mpassword").val("");
		$("#cpassword").val("");
		$("#mdate1").val("");
		$(".hobbiesclass").val("");
		$("#Address").val("")
		$("#dropdown").val("")
		$("#loginEmail").val("")
		$("#loginpassword").val("");
	}
	
	this.chagepopup=chagepopup
	function chagepopup(classvalue)
	{
		removepopup();
		if(classvalue.id==1)
		{
			registerpopup();
		}
		else
		{
			loginpopup();
		}
	}

	this.resrictbuttons=resrictbuttons;
	function resrictbuttons(event)
	{
		var n=event.keycode || event.which;
		if(n>64 && n<91)
		{
			return true;
		}
		else if(n>96 && n<123)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	this.resrictbuttons1=resrictbuttons1;
	function resrictbuttons1(event)
	{
		var n=event.keycode || event.which;
		if(n>47 && n<58)
		{
			return true;
		}
		//else if(n>95 && n<106)
		//{
		//	return true;
		//}
		else
		{
			return false;
		}
	}
	
	
	this.ajaxEmailcheck=ajaxEmailcheck;
	function ajaxEmailcheck()
	{
		var contextpath=$("#contextpath").val();
		var email=$("#loginEmail").val();
		
		$.post(contextpath+"/ajax/ajaxController.jsp",
				{
					action : "checkEmail",
					email : email
				},
				function(tempdata)
				{
					console.log(tempdata);
					var parsedata=JSON.parse(tempdata);
					if(parsedata.status)
					{
						$("#Emailerror").text(parsedata.data+" "+parsedata.message);
					}
					else
					{
						$("#Emailerror").text(parsedata.message);
					}
						
				}
		);
	}
	
	this.ajaxPasswordCheck=ajaxPasswordCheck;
	function ajaxPasswordCheck()
	{
		var contextpath=$("#contextpath").val();
		var email=$("#loginEmail").val();
		var password=$("#loginpassword").val();
		
		$.post(contextpath+"/ajax/ajaxController.jsp",
				{
					action : "password",
					password : password,
					email : email
				},
				function(tempdata)
				{
					console.log(tempdata);
					var parsedata=JSON.parse(tempdata);
					if(parsedata.status)
					{
						$("#passworderror").text(parsedata.data+" "+parsedata.message);
					}
					
				}
		);
	}
	
	this.ajaxRegistrationEmailcheck=ajaxRegistrationEmailcheck;
	function ajaxRegistrationEmailcheck()
	{
		var contextpath=$("#contextpath").val();
		var email=$("#Email").val();
		
		$.post(contextpath+"/ajax/ajaxController.jsp",
				{
					action : "Email",
					email : email
				},
				function(tempdata)
				{
					console.log(tempdata);
					var parsedata=JSON.parse(tempdata);
					if(!parsedata.status)
					{
						return true;
					}
					else
					{
						$("#spanEmail").text(parsedata.data+" "+parsedata.message);
						return false;
						
					}
				
					
				}
		);
	}
	this.ajaxMobileCheck=ajaxMobileCheck;
	function ajaxMobileCheck()
	{
		var contextpath=$("#contextpath").val();
		var mobile=$("#Mobile").val();
		
		$.post(contextpath+"/ajax/ajaxController.jsp",
				{
					action : "mobile",
					mobile : mobile,
					
				},
				function(tempdata)
				{
					console.log(tempdata);
					var parsedata=JSON.parse(tempdata);
					if(!parsedata.status)
					{
						return true;
					}
					else
					{
						$("#spanmobile").text(parsedata.data+" "+parsedata.message);
						return false;
					}
			}
		);
	}
	
	this.loginUserOrAdmin=loginUserOrAdmin;
	function loginUserOrAdmin()
	{
		var contextpath=$("#contextpath").val();
		var email=$("#loginEmail").val();
		var password=$("#loginpassword").val();
		
		$.post(contextpath+"/ajax/ajaxController.jsp",
				{
					action : "loginUserOrAdmin",
					password : password,
					email : email
				},
				function(tempdata)
				{
					var parsedata=JSON.parse(tempdata);
					if(parsedata.status)
					{
						if((parsedata.entry)==("y"))
						{	
							window.location.replace(contextpath+"/jsp/admin.jsp");
						}
						else
						{
							window.location.replace(contextpath+"/jsp/user.jsp");
						}
					}
				}
		);
	}
	
	this.showtable=showtable;
	function showtable()
	{
		var contextpath=$("#contextpath").val();
		$.post(contextpath+"/ajax/ajaxController.jsp",
				{
					action : "showtable",
										
				},
				function(tempdata)
				{
					console.log(tempdata);
					var parsedata=JSON.parse(tempdata);
					if(parsedata.status)
					{
						var listdata=parsedata.list;
						length=listdata.length;
						length=length/11;
						rows=length;
						count=0;
						column=11;
						tabledata='';
						for(i=0;i<rows;i++)
						{
							tabledata+='<tr>';
							for(j=0;j<column;j++)
							{
								tabledata+='<td>';
								tabledata+=''+listdata[count++];
								tabledata+='</td>';
							}
							tabledata+='</tr>';
						}
						
						$("#showdiv").append(tabledata);
						$("#divdata").removeAttr("onclick");
					}
				});
	}
	
	this.logout=logout;
	function logout()
	{
		var contextpath=$("#contextpath").val();
		window.location.replace(contextpath+"/jsp/logout.jsp");
	}
	
}

