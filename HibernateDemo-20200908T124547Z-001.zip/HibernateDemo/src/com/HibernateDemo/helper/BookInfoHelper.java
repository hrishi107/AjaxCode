package com.HibernateDemo.helper;

public class BookInfoHelper {

}
