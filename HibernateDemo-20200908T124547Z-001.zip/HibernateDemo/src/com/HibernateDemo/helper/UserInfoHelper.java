package com.HibernateDemo.helper;

import java.util.List;

import com.HibernateDemo.dao.UserInfoDao;
import com.HibernateDemo.pojo.UserInfo;

public class UserInfoHelper 
{
	public boolean addUser(UserInfo user)
	{
		return false;
	}
	
	public List getUsers()
	{
		return new UserInfoDao().getUser();
	}
	
	
}
