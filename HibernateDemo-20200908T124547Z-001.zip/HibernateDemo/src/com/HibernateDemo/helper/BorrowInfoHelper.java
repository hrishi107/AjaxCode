package com.HibernateDemo.helper;

import java.util.ArrayList;
import java.util.List;

import com.HibernateDemo.beans.UserBookBean;
import com.HibernateDemo.dao.BorrowInfoDao;

public class BorrowInfoHelper 
{
	public List getListOfUserBooks(String userId)
	{
		List list = new BorrowInfoDao().getListOfUserBooks(new Long(userId));
		
		List bookList = null;
		
		if(list != null && list.size()>0)
		{
			bookList = new ArrayList();
			for(int i=0; i < list.size(); i++)
			{
				Object[] obj = (Object[])list.get(i);
				
				UserBookBean bean = new UserBookBean();
				bean.setUserName(obj[0] + " " + obj[1]);
				bean.setBookName(obj[2].toString());
				bean.setPublicaation(obj[3].toString());
				
				bookList.add(bean);
			}
		}
		return bookList;
	}
}
