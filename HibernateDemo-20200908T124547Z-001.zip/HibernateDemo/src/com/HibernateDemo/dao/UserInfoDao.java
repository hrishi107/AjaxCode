package com.HibernateDemo.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.HibernateDemo.pojo.UserInfo;
import com.HibernateDemo.utils.ConfigDB;

public class UserInfoDao
{
	public UserInfo addUser(UserInfo user)
	{
		Session session = ConfigDB.getSession();
		Transaction tx =  session.beginTransaction();
		try
		{
			session.save(user);
			tx.commit();
		}
		catch(Exception e)
		{
			tx.rollback();
			e.printStackTrace();
		}
		finally 
		{
			ConfigDB.closeSession(session);
		}
		return user;
	}
	
	public List getUser()
	{
		List list = null;
		Session session = ConfigDB.getSession();
		
		String queryString = "SELECT userInfo.pkUserId, userInfo.firstName"
							+ " FROM UserInfo userInfo";
		
		Query query = session.createQuery(queryString);
		
		list = query.list();
		
		
		return list;
	}
	
	
	public static void main(String args[])
	{
		Session session = ConfigDB.getSession();
		System.out.println("====================Query1--Session1--UserId:1  ===========================");
		UserInfo user1 = (UserInfo)session.get(UserInfo.class, 1L);
		System.out.println("====================================================");
		System.out.println("=========User Name===" + user1.getFirstName());
		
		System.out.println("====================Query2--Session1--UserId:2  ===========================");
		UserInfo user2 = (UserInfo)session.get(UserInfo.class, 2L);
		System.out.println("====================================================");
		
		System.out.println("=========User Name===" + user2.getFirstName());
		
		System.out.println("====================Query3--Session1--UserId:1  ===========================");
		UserInfo user3 = (UserInfo)session.get(UserInfo.class, 1L);
		System.out.println("====================================================");

		System.out.println("=========User Name===" + user3.getFirstName());
		
		Session session2 = ConfigDB.getSession();
		
		System.out.println("====================Query4--Session2--UserId:1  ===========================");
		UserInfo user4 = (UserInfo)session2.get(UserInfo.class, 1L);
		System.out.println("====================================================");
			
		System.out.println("=========User Name===" + user4.getFirstName());
		
		ConfigDB.closeSession(session);
		ConfigDB.closeSessionFactory();
	}
	
}
