package com.HibernateDemo.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.HibernateDemo.pojo.BorrowInfo;
import com.HibernateDemo.utils.ConfigDB;

public class BorrowInfoDao 
{
	public BorrowInfo borrowBook(BorrowInfo borrow)
	{
		Session session = ConfigDB.getSession();
		Transaction tx = session.beginTransaction();
		try
		{
			session.save(borrow);
			tx.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			tx.rollback();
		}
		finally
		{
			ConfigDB.closeSessionFactory();
		}
		return borrow;
	}
	
	
	public List getListOfUserBooks(Long userId)
	{
		List list = null;
		Session session = ConfigDB.getSession();
		
		String queryString = " SELECT user.firstName, user.lastName, book.bookName, book.publication"
							+ " FROM BorrowInfo borrow"
							+ " JOIN borrow.userInfo user"
							+ " JOIN borrow.bookInfo book"
							+ " WHERE user.pkUserId=:pkUserId";
		
		Query query = session.createQuery(queryString);
		query.setParameter("pkUserId", userId);
		list = query.list();
		
		return list;
	}
}
