package com.HibernateDemo.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.HibernateDemo.pojo.BookInfo;
import com.HibernateDemo.utils.ConfigDB;

public class BookInfoDao 
{
	public BookInfo addBook(BookInfo book)
	{
		Session session = ConfigDB.getSession();
		Transaction tx = session.beginTransaction();
		try
		{
			session.save(book);
			tx.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			tx.rollback();
		}
		finally
		{
			ConfigDB.closeSessionFactory();
		}
		return book;
	}
}
