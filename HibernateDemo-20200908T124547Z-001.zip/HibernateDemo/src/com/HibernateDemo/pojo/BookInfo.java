package com.HibernateDemo.pojo;

import java.util.Set;

public class BookInfo 
{
	private Long pkBookId;
	private String bookName;
	private String publication;
	
	private Set<BorrowInfo> borrowInfo;

	
	public Long getPkBookId() {
		return pkBookId;
	}

	public void setPkBookId(Long pkBookId) {
		this.pkBookId = pkBookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getPublication() {
		return publication;
	}

	public void setPublication(String publication) {
		this.publication = publication;
	}

	public Set<BorrowInfo> getBorrowInfo() {
		return borrowInfo;
	}

	public void setBorrowInfo(Set<BorrowInfo> borrowInfo) {
		this.borrowInfo = borrowInfo;
	}
	
	
}
