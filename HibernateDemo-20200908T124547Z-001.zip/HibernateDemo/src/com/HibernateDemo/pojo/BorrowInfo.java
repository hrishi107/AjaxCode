package com.HibernateDemo.pojo;

public class BorrowInfo 
{
	private Long pkBorrowId;
	private UserInfo userInfo;
	private BookInfo bookInfo;
	
	public Long getPkBorrowId() {
		return pkBorrowId;
	}
	public void setPkBorrowId(Long pkBorrowId) {
		this.pkBorrowId = pkBorrowId;
	}
	public UserInfo getUserInfo() {
		return userInfo;
	}
	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}
	public BookInfo getBookInfo() {
		return bookInfo;
	}
	public void setBookInfo(BookInfo bookInfo) {
		this.bookInfo = bookInfo;
	}
}
