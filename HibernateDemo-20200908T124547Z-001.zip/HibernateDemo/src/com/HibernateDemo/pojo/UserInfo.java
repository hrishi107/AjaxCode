package com.HibernateDemo.pojo;

import java.util.Set;

public class UserInfo 
{
	private Long pkUserId;
	private String firstName;
	private String lastName;
	
	private Set<BorrowInfo> borrowInfo;

	public Long getPkUserId() {
		return pkUserId;
	}

	public void setPkUserId(Long pkUserId) {
		this.pkUserId = pkUserId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Set<BorrowInfo> getBorrowInfo() {
		return borrowInfo;
	}

	public void setBorrowInfo(Set<BorrowInfo> borrowInfo) {
		this.borrowInfo = borrowInfo;
	}
	
	
}
