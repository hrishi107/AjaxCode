package com.HibernateDemo.beans;

public class UserBookBean
{
	private String userName;
	private String bookName;
	private String publicaation;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getPublicaation() {
		return publicaation;
	}
	public void setPublicaation(String publicaation) {
		this.publicaation = publicaation;
	}
	
	
}
